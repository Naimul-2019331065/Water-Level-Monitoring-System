/*
 * OTA is not ready for this board yet.
 * It could be derived from:
 * https://www.hackster.io/flower-platform/program-mkr-over-the-air-goodies-voice-control-etc-562e9a
 */

String overTheAirURL;

BLYNK_WRITE(InternalPinOTA) {
  overTheAirURL = param.asString();

  delay(500);
  // Disconnect, not to interfere with OTA process
  Blynk.disconnect();

  // Start OTA
  BlynkState::set(MODE_OTA_UPGRADE);
}

void enterOTA() {
  BlynkState::set(MODE_ERROR);
}

